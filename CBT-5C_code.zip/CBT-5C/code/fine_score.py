# 微调前后效果评估，gpt-5.5打分
import pandas as pd
import requests
import json
import time
import logging
from typing import Dict, Tuple

# 配置
INPUT_PATH = r"D:\VSCodeProject\CBT_5C\fine_score.xlsx"
OUTPUT_PATH = r"D:\VSCodeProject\CBT_5C\fine_score_result.xlsx"
API_KEY = "sk-uoCb6hXbO3wNGeAXsMYRbmsAwkLhzUMZmBrb7qOHtzjcVQ54"
BASE_URL = "https://sg.uiuiapi.com/v1"
MODEL = "gpt-5.5"

# 日志配置
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 评分标准
SYSTEM_PROMPT = """你是 CBT（认知行为疗法）专家。请严格按照以下标准，对两个替代思维进行评分（每个维度分数及总分），并判断哪个更好或平局。

【评分标准】（总分4-10分）
- 逻辑合理性 (1-3分)：基于情境事实，推理无跳跃，不极端化。
- 针对性 (1-3分)：是否直接回应用户原始自动思维（如“毁掉幻想”“不信任所有人”）和认知扭曲（如过度泛化）。
- 情感共情度 (1-2分)：语气温暖、接纳，承认情绪的合理性。
- 建设性 (1-2分)：提供具体、可操作的替代视角或行动方向。

【输出格式】（必须严格遵守，每行一个字段）
    fine_reframing总分: [数字]
    fine_CBT5C总分: [数字]
胜负: [fine_reframing胜 / fine_CBT5C胜 / 平局]
评价: [简要说明分数理由，不超过60字]
"""

def get_llm_evaluation(prompt_text: str, response_patternreframe: str, response_cbt5c: str, max_retries=3) -> Tuple[Dict, str]:
    """
    调用 GPT 模型，获得两个回复的评分和胜负判断。
    返回字典包含 fine_reframing总分, fine_CBT5C总分, 胜负, 评价
    """
    user_content = f"""
【原始情境/自动思维/认知扭曲/情绪】
{prompt_text}

【待评价的替代思维】
- PatternReframe生成: {response_patternreframe}
- CBT-5C生成: {response_cbt5c}

请按照标准输出格式评分。"""
    
    for attempt in range(max_retries):
        try:
            payload = {
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_content}
                ],
                "temperature": 0.1,
                "max_tokens": 200
            }
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {API_KEY}"
            }
            url = f"{BASE_URL}/chat/completions"
            resp = requests.post(url, headers=headers, json=payload, timeout=30)
            
            if resp.status_code == 200:
                content = resp.json()["choices"][0]["message"]["content"].strip()
                result = {"fine_reframing总分": None, "fine_CBT5C总分": None, "胜负": "", "评价": ""}
                for line in content.split('\n'):
                    line = line.strip()
                    if line.startswith("fine_reframing总分:"):
                        try:
                            result["fine_reframing总分"] = int(line.split(":")[1].strip())
                        except:
                            pass
                    elif line.startswith("fine_CBT5C总分:"):
                        try:
                            result["fine_CBT5C总分"] = int(line.split(":")[1].strip())
                        except:
                            pass
                    elif line.startswith("胜负:"):
                        result["胜负"] = line.split(":")[1].strip()
                    elif line.startswith("评价:"):
                        result["评价"] = line.split(":")[1].strip()
                
                # 校验分数有效性
                if (result["fine_reframing总分"] is not None and 4 <= result["fine_reframing总分"] <= 10 and
                    result["fine_CBT5C总分"] is not None and 4 <= result["fine_CBT5C总分"] <= 10):
                    return result, content
                else:
                    logger.warning(f"分数解析越界或缺失，原始返回：{content}")
                    if result["fine_reframing总分"] is None: result["fine_reframing总分"] = 5
                    if result["fine_CBT5C总分"] is None: result["fine_CBT5C总分"] = 5
                    if not result["胜负"]:
                        result["胜负"] = "平局" if result["fine_reframing总分"] == result["fine_CBT5C总分"] else \
                                        ("fine_reframing胜" if result["fine_reframing总分"] > result["fine_CBT5C总分"] else "fine_CBT5C胜")
                    return result, content
            else:
                logger.warning(f"API 错误 {resp.status_code}: {resp.text}")
                time.sleep(2)
        except Exception as e:
            logger.error(f"第{attempt+1}次尝试失败: {e}")
            time.sleep(2)
    
    return {"fine_reframing总分":5, "fine_CBT5C总分":5, "胜负":"平局", "评价":"请求失败"}, ""

def main():
    try:
        df = pd.read_excel(INPUT_PATH, engine='openpyxl')
        logger.info(f"成功读取 {len(df)} 行数据，列名：{df.columns.tolist()}")
    except Exception as e:
        logger.error(f"读取文件失败：{e}")
        return
    
    required_cols = ["情境/触发事件", "自动思维", "认知扭曲", "情绪", "fine_patternreframe", "fine_CBT5C"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        logger.error(f"缺少必要列：{missing}，实际列：{df.columns.tolist()}")
        return
    
    # 添加评分结果列
    df["fine_patternreframe总分"] = None
    df["fine_CBT5C总分"] = None
    df["胜负"] = ""
    df["模型评价"] = ""
    df["原始返回"] = ""
    
    total = len(df)
    for idx, row in df.iterrows():
        logger.info(f"处理第 {idx+1}/{total} 行")
        
        prompt_text = f"""情境/触发事件：{row['情境/触发事件']}
自动思维：{row['自动思维']}
认知扭曲：{row['认知扭曲']}
情绪：{row['情绪']}"""
        
        patternreframe_text = str(row['fine_patternreframe']) if pd.notna(row['fine_patternreframe']) else ""
        cbt5c_text = str(row['fine_CBT5C']) if pd.notna(row['fine_CBT5C']) else ""
        
        if not patternreframe_text or not cbt5c_text:
            logger.warning(f"第{idx+1}行存在空回复，跳过评分")
            df.at[idx, "胜负"] = "跳过"
            continue
        
        result, raw = get_llm_evaluation(prompt_text, patternreframe_text, cbt5c_text)
        df.at[idx, "fine_patternreframe总分"] = result["fine_reframing总分"]
        df.at[idx, "fine_CBT5C总分"] = result["fine_CBT5C总分"]
        df.at[idx, "胜负"] = result["胜负"]
        df.at[idx, "模型评价"] = result["评价"]
        df.at[idx, "原始返回"] = raw[:200]
        
        logger.info(f"结果：PatternReframe={result['fine_reframing总分']}, CBT5C={result['fine_CBT5C总分']}, {result['胜负']}")
        
        if (idx + 1) % 5 == 0:
            df.to_excel(OUTPUT_PATH, index=False, engine='openpyxl')
            logger.info(f"已保存进度至第{idx+1}行")
        
        time.sleep(0.5)
    
    df.to_excel(OUTPUT_PATH, index=False, engine='openpyxl')
    logger.info(f"评分完成，结果已保存至 {OUTPUT_PATH}")
    
    # 统计
    valid = df[df["胜负"].isin(["fine_reframing胜", "fine_CBT5C胜", "平局"])]
    if len(valid) > 0:
        win_patternreframe = (valid["胜负"] == "fine_reframing胜").sum()
        win_cbt5c = (valid["胜负"] == "fine_CBT5C胜").sum()
        tie = (valid["胜负"] == "平局").sum()
        logger.info(f"统计：PatternReframe胜 {win_patternreframe} 场，CBT-5C胜 {win_cbt5c} 场，平局 {tie} 场")
    else:
        logger.warning("无有效评分结果")

if __name__ == "__main__":
    main()
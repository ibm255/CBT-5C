# 将情绪列处理到不多于三个情绪

import pandas as pd

# 文件路径
input_path = r"D:\VSCodeProject\CBT_5C\dataset_7329.xlsx"
output_path = r"D:\VSCodeProject\CBT_5C\result.xlsx"

def trim_emotion(emotion_str):
    """去除字符串两端空格，并处理可能的空值"""
    if pd.isna(emotion_str):
        return ""
    return str(emotion_str).strip()

def process_emotions(emotion_str):
    """
    处理情绪字符串：
    - 按逗号分割，去除空白
    - 如果长度 ≤3，直接返回原字符串（保持格式）
    - 如果长度 >3：
        - 若存在 "恐惧"，则保留它，并从右向左删除其他情绪直到总数为3
        - 否则，保留前三个情绪
    - 返回用逗号+空格连接的字符串
    """
    if pd.isna(emotion_str) or emotion_str == "":
        return ""
    
    # 分割并去除空白
    emotions = [e.strip() for e in str(emotion_str).split(",") if e.strip()]
    
    if len(emotions) <= 3:
        return ", ".join(emotions)
    
    # 长度 > 3
    if "恐惧" in emotions:
        # 保留恐惧，从右向左删除其他情绪，直到总数为3
        # 复制列表，从右向左遍历，标记要删除的索引
        to_keep = emotions.copy()  # 先全部保留
        # 从右向左删除非"恐惧"的元素，直到长度=3
        # 不删除"恐惧"
        while len(to_keep) > 3:
            # 从最右边开始找第一个不是"恐惧"的位置
            for i in range(len(to_keep)-1, -1, -1):
                if to_keep[i] != "恐惧":
                    del to_keep[i]
                    break
        return ", ".join(to_keep)
    else:
        # 无恐惧，保留前三个
        return ", ".join(emotions[:3])

# 读取数据
df = pd.read_excel(input_path)

emotion_col = "情绪"

# 处理情绪列
df[emotion_col] = df[emotion_col].apply(process_emotions)

# 保存结果
df.to_excel(output_path, index=False)

print(f"处理完成，结果保存至: {output_path}")
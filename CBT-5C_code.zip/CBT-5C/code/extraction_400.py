import pandas as pd
import numpy as np

# 设置随机种子，保证可复现
np.random.seed(42)

# 1. 读取原始数据
df = pd.read_excel(r"D:\VSCodeProject\CBT_5C\dataset_7329.xlsx")

# 2. 定义六种基本情绪
BASIC_EMOTIONS = ['恐惧', '悲伤', '愤怒', '厌恶', '惊讶', '快乐']

def get_primary_emotion(emo_str):
    """从可能的多标签字符串中提取第一个基本情绪，无则返回'其他'"""
    if pd.isna(emo_str):
        return '其他'
    parts = [e.strip() for e in str(emo_str).split(',')]
    for e in parts:
        if e in BASIC_EMOTIONS:
            return e
    return '其他'

# 3. 构建分层键
primary_emo = df['情绪'].apply(get_primary_emotion)
distortion = df['认知扭曲/标签']
strata_key = distortion + ' | ' + primary_emo

# 4. 分层抽样：每层至少抽5条（不足则全取）
groups = df.groupby(strata_key)
selected_indices = []

for key, group in groups:
    n = min(5, len(group))
    sampled = group.sample(n=n, random_state=42)
    selected_indices.extend(sampled.index.tolist())

# 5. 去重后若不足400，从剩余样本中随机补齐
selected_set = set(selected_indices)
if len(selected_set) < 400:
    remaining = df.index.difference(selected_set)
    extra = np.random.choice(remaining, size=400 - len(selected_set), replace=False)
    selected_set.update(extra)

# 确保刚好400条
selected_set = set(list(selected_set)[:400])

# 6. 提取子集并直接输出原始六列（不做任何列增删）
df_out = df.loc[list(selected_set)]

output_path = r"D:\VSCodeProject\CBT_5C\dataset_PeopleEvaluate.xlsx"
df_out.to_excel(output_path, index=False)

print(f"抽取完成！共抽取 {len(df_out)} 条数据，已保存至：{output_path}")
print(f"认知扭曲类型覆盖数：{df_out['认知扭曲/标签'].nunique()}")
# 计算替代思维相似度
import pandas as pd
from transformers import AutoTokenizer, AutoModel
import torch
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import os

# ---------- 配置 ----------
# 文件路径
INPUT_PATH = r"D:\VSCodeProject\CBT_5C\test.xlsx"
OUTPUT_PATH = r"D:\VSCodeProject\CBT_5C\result.xlsx"

# 本地模型路径
MODEL_PATH = r"D:\dachuang\models\Chinese-MentalBERT"

# 三个模型列名
MODEL_COLS = ['gpt-5.5替代思维', 'Qwen/Qwen3.6-27B替代思维', 'deepseek-chat替代思维']
MODEL_NAMES = ['gpt5.5', 'qwen3.6', 'deepseek']

# ---------- 加载模型 ----------
print("正在加载模型和tokenizer...")
try:
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    model = AutoModel.from_pretrained(MODEL_PATH, trust_remote_code=True)
    print("模型加载成功！")
except Exception as e:
    print(f"模型加载失败: {e}")
    exit()

model.eval()

# ---------- 读取数据 ----------
print(f"正在读取 Excel 文件: {INPUT_PATH}")
try:
    df = pd.read_excel(INPUT_PATH)
except Exception as e:
    print(f"读取文件失败: {e}")
    exit()

print(f"成功读取数据，共 {len(df)} 行")

# 检查列是否存在
for col in MODEL_COLS:
    if col not in df.columns:
        print(f"错误: 列 '{col}' 不在Excel文件中")
        print(f"可用的列: {df.columns.tolist()}")
        exit()

# ---------- 定义嵌入生成函数 ----------
def get_embeddings(texts, batch_size=16):
    """使用MentalBERT生成文本嵌入，分批处理避免内存爆炸"""
    all_embeddings = []
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i+batch_size]
        try:
            inputs = tokenizer(
                batch_texts,
                padding=True,
                truncation=True,
                return_tensors="pt",
                max_length=512
            )
            with torch.no_grad():
                outputs = model(**inputs)
                # 使用 [CLS] token 的嵌入
                batch_emb = outputs.last_hidden_state[:, 0, :].numpy()
            all_embeddings.append(batch_emb)
        except Exception as e:
            print(f"批次 {i}-{i+batch_size} 处理失败: {e}")
            # 返回零向量作为占位
            zero_emb = np.zeros((len(batch_texts), model.config.hidden_size))
            all_embeddings.append(zero_emb)
    return np.vstack(all_embeddings)

# ---------- 生成嵌入向量 ----------
embeddings = {}
print("开始生成文本嵌入向量...")

for col in MODEL_COLS:
    # 处理缺失值：将 NaN 转为空字符串
    texts = df[col].fillna("").astype(str).tolist()
    print(f"处理列 '{col}'，共 {len(texts)} 条文本")
    col_emb = get_embeddings(texts, batch_size=16)
    embeddings[col] = col_emb
    print(f"完成，嵌入形状: {col_emb.shape}")

# ---------- 计算加权平均嵌入 ----------
# 三个模型等权重
weights = [1/3, 1/3, 1/3]
avg_embeddings = np.zeros_like(embeddings[MODEL_COLS[0]])
for i, col in enumerate(MODEL_COLS):
    avg_embeddings += weights[i] * embeddings[col]

# ---------- 逐行计算相似度 ----------
results = []
print("正在计算余弦相似度...")
for idx in range(len(df)):
    row_result = {
        'row_index': idx,
        'Num': df.loc[idx, 'Num'] if 'Num' in df.columns else idx  # 如果无Num列，使用行索引
    }
    sim_values = []
    for j, col in enumerate(MODEL_COLS):
        emb = embeddings[col][idx].reshape(1, -1)
        avg_emb = avg_embeddings[idx].reshape(1, -1)
        sim = cosine_similarity(emb, avg_emb)[0][0]
        row_result[f'{MODEL_NAMES[j]}_similarity'] = sim
        sim_values.append(sim)
    row_result['average_similarity'] = np.mean(sim_values)
    results.append(row_result)

    if (idx + 1) % 50 == 0:
        print(f"已处理 {idx+1}/{len(df)} 行")

# ---------- 保存结果 ----------
result_df = pd.DataFrame(results)

column_order = ['row_index', 'Num'] + [f'{name}_similarity' for name in MODEL_NAMES] + ['average_similarity']
result_df = result_df[column_order]

result_df.to_excel(OUTPUT_PATH, index=False, engine='openpyxl')
print(f"\n结果已保存至: {OUTPUT_PATH}")

# ---------- 统计信息 ----------
print("\n=== 相似度统计信息 ===")
avg_mean = result_df['average_similarity'].mean()
avg_min = result_df['average_similarity'].min()
avg_max = result_df['average_similarity'].max()
avg_std = result_df['average_similarity'].std()
print(f"平均相似度 (所有行): {avg_mean:.6f}")
print(f"最小相似度: {avg_min:.6f}")
print(f"最大相似度: {avg_max:.6f}")
print(f"标准差: {avg_std:.6f}")

print("\n各模型与加权平均向量的平均相似度:")
for name in MODEL_NAMES:
    col = f'{name}_similarity'
    mean_val = result_df[col].mean()
    print(f"{name}: {mean_val:.6f}")

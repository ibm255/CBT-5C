# 人工校验后，计算一致性
import pandas as pd
import numpy as np
from sklearn.metrics import cohen_kappa_score, precision_recall_fscore_support

# 读取数据
df = pd.read_excel("D:/VSCodeProject/CBT_5C/test.xlsx")

# 情绪类别列表
EMOTIONS = ['恐惧', '悲伤', '愤怒', '厌恶', '惊讶', '快乐', '中性']

# 解析专家真实情绪标签
def parse_emotion_labels(row, expert_col, correction_col):
    """
    根据专家认可标记和修正列，返回该专家对该样本的7维情绪向量。
    row: DataFrame的一行
    expert_col: '专家1' 或 '专家2'
    correction_col: '专家1的修正' 或 '专家2的修正'
    """
    if pd.isna(row[expert_col]):
        return [0]*7
    
    if row[expert_col] == 1:
        llm_label = row['情绪']
        if pd.isna(llm_label) or llm_label == '':
            return [0]*7
        labels = [x.strip() for x in llm_label.split(',')] if ',' in llm_label else [llm_label]
        if '中性' in labels:
            vec = [0]*7
            vec[EMOTIONS.index('中性')] = 1
        else:
            vec = [1 if emo in labels else 0 for emo in EMOTIONS[:-1]] + [0]
        return vec
    else:
        corr = row[correction_col]
        if pd.isna(corr) or corr == '':
            return [0]*7
        if corr == '中性':
            vec = [0]*7
            vec[EMOTIONS.index('中性')] = 1
        else:
            labels = [x.strip() for x in corr.split(',')]
            vec = [1 if emo in labels else 0 for emo in EMOTIONS[:-1]] + [0]
        return vec

n = len(df)
exp1_matrix = np.zeros((n, 7), dtype=int)
exp2_matrix = np.zeros((n, 7), dtype=int)

for i, row in df.iterrows():
    exp1_matrix[i] = parse_emotion_labels(row, '专家1', '专家1的修正')
    exp2_matrix[i] = parse_emotion_labels(row, '专家2', '专家2的修正')

# 专家间情绪Kappa（每个类别）
kappa_per_emotion = []
for idx, emo in enumerate(EMOTIONS):
    y1 = exp1_matrix[:, idx]
    y2 = exp2_matrix[:, idx]
    if np.sum(y1) == 0 and np.sum(y2) == 0:
        continue
    try:
        k = cohen_kappa_score(y1, y2)
        kappa_per_emotion.append(k)
        print(f"{emo}: Cohen's Kappa = {k:.4f}")
    except Exception as e:
        print(f"{emo}: 计算失败 - {e}")

macro_kappa = np.mean(kappa_per_emotion)
print(f"\n宏平均Kappa (7类): {macro_kappa:.4f}")

# 专家间替代思维一致性
score1_raw = df['专家1打分'].values
score2_raw = df['专家2打分'].values
score1_bin = np.where(score1_raw == 3, 1, 0)
score2_bin = np.where(score2_raw == 3, 1, 0)

# 去除缺失值
valid = ~(pd.isna(score1_raw) | pd.isna(score2_raw))
score1_clean = score1_bin[valid]
score2_clean = score2_bin[valid]

# 计算二分类 Cohen's Kappa
alt_kappa = cohen_kappa_score(score1_clean, score2_clean)
print(f"\n替代思维认可度专家间Kappa (二分类，3→认可): {alt_kappa:.4f}")

# 总体一致率
agreement = (score1_clean == score2_clean).mean() * 100
print(f"总体一致率: {agreement:.2f}%")

# 专家共识 vs LLM（情绪部分，与之前完全相同）
def parse_llm_labels(row):
    llm_label = row['情绪']
    if pd.isna(llm_label) or llm_label == '':
        return [0]*7
    labels = [x.strip() for x in llm_label.split(',')] if ',' in llm_label else [llm_label]
    if '中性' in labels:
        vec = [0]*7
        vec[EMOTIONS.index('中性')] = 1
    else:
        vec = [1 if emo in labels else 0 for emo in EMOTIONS[:-1]] + [0]
    return vec

llm_matrix = np.array([parse_llm_labels(row) for _, row in df.iterrows()])

print("\n专家共识 vs LLM 性能（排除分歧样本）:")
for idx, emo in enumerate(EMOTIONS):
    exp1_col = exp1_matrix[:, idx]
    exp2_col = exp2_matrix[:, idx]
    consensus_mask = (exp1_col == exp2_col)
    if np.sum(consensus_mask) == 0:
        print(f"{emo}: 无一致样本，跳过")
        continue
    y_true = exp1_col[consensus_mask]
    y_pred = llm_matrix[consensus_mask, idx]
    if len(np.unique(y_true)) < 2:
        k = np.nan
    else:
        k = cohen_kappa_score(y_true, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average='binary', zero_division=0)
    k_str = f"{k:.4f}" if not np.isnan(k) else "NaN"
    print(f"{emo}: Kappa={k_str}, P={precision:.4f}, R={recall:.4f}, F1={f1:.4f}")
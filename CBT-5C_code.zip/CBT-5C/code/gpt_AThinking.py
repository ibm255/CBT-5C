# gpt-5.5 生成替代思维（带内容有效性重试）

import pandas as pd
import time
import re
import requests

# ---------- 配置 ----------
INPUT_PATH = r"D:/VSCodeProject/CBT_5C/test.xlsx"
OUTPUT_PATH = r"D:/VSCodeProject/CBT_5C/result.xlsx"
API_KEY = "sk-uoCb6hXbO3wNGeAXsMYRbmsAwkLhzUMZmBrb7qOHtzjcVQ54"
BASE_URL = "https://sg.uiuiapi.com/v1"
MODEL = "gpt-5.5"

# 提示词模板
PROMPT_TEMPLATE = """你是一位专业的认知行为治疗师。用户正在做CBT五栏表日常练习，已填写前四栏，请你协助生成第五栏「替代思维」。

【生成规则】
1. 替代思维必须基于事实、理性、灵活，字数控制在25~55字之间。
2. 直接针对自动思维中的认知扭曲（如灾难化、贴标签、情绪化推理等）进行平衡与反驳。
3. 禁止使用“一定会”“马上会”“永远不会”等绝对化预言；避免简单的积极喊话（如“一切都好”）。
4. 允许使用“虽然…但是…”“即使…我也能…”“我注意到…事实上…”等句式，但不要每句都套模板。
5. 语气温和、有自我同情色彩，认可情绪的存在但不过度认同自动思维。
6. 如果自动思维中有自我贬低（如“我是蠢货”），替代思维需区分“行为/事件”与“自我价值”。

【示例】（仅供格式与风格参考，不要照抄具体内容）
示例1：
情境/触发事件：阿富汗战争导致你的股票跳水
自动思维：这些钱就是为我的愚蠢买单的我真是个无可救药的蠢货
认知扭曲/标签：情绪化推理、乱贴标签
情绪：恐惧, 悲伤
替代思维：战争导致全球股市普遍下跌，这是一次外部冲击，并非因为我“愚蠢”。我可以把这次亏损看作学习机会，未来分散投资降低风险。

示例2：
情境/触发事件：阿富汗战争导致你的股票跳水
自动思维：我早晚被股票害死，我干嘛去碰这条股票啊
认知扭曲/标签：情绪化推理
情绪：恐惧, 愤怒, 悲伤, 厌恶
替代思维：投资必然伴随风险，这次大幅亏损让我很痛苦。但我没有“被害死”，账户仍有剩余资金。我可以暂停冲动操作，先研究战争对持仓行业的具体影响。

示例3：
情境/触发事件：阿富汗战争导致你的股票跳水
自动思维：自认倒霉吧，反正我投什么什么就衰气
认知扭曲/标签：情绪化推理
情绪：悲伤, 愤怒, 恐惧, 厌恶
替代思维：“投什么什么衰”是过度概括。过去我也曾有过盈利的投资，只是这次遇到黑天鹅事件。我可以把战乱导致亏损与个人运气分开看待。

示例4：
情境/触发事件：奔波多年，你发现自己的积蓄并没与攒到多少
自动思维：在接下来的十几年，我将靠着这点死工资度日，这些工资根本是存不下来的
认知扭曲/标签：情绪化推理、预测未来
情绪：恐惧, 悲伤
替代思维：按照目前工资确实存钱慢，但“根本存不下来”是绝对化预测。我可以先记账3个月，找到每月可节省的金额，同时尝试兼职或升职加薪机会。

示例5：
情境/触发事件：奔波多年，你发现自己的积蓄并没与攒到多少
自动思维：奔波这么多年也没空陪陪爸妈，现在钱也没赚到。我真是个不孝子
认知扭曲/标签：乱贴标签
情绪：悲伤
替代思维：孝顺不只用金钱和陪伴时长衡量。我远离家乡奋斗也是为了让父母放心。现在可以每周固定打两次视频电话，休假时回去住几天，慢慢改善陪伴质量。

【输出格式】
严禁输出任何思考过程、解释、标签（如<think>、</think>、注释等）。只输出替代思维的纯文本内容，不要添加引号、序号或额外信息。

【以下为用户提供的前四栏】
情境/触发事件：{situation}
自动思维：{automatic_thought}
认知扭曲/标签：{cognitive_distortion}
情绪：{emotion}

请输出替代思维："""

# ---------- 辅助函数 ----------
def clean_alternative(text):
    """移除模型可能输出的<think>...</think>标签及其内容"""
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    cleaned = re.sub(r"</?think>", "", cleaned, flags=re.IGNORECASE)
    cleaned = cleaned.strip()
    return cleaned

def generate_alternative_with_retry(situation, auto_thought, distortion, emotion, max_attempts=3):
    """
    调用 API 生成替代思维，如果内容过短（长度<5）则重试，最多 max_attempts 次。
    返回有效的替代思维文本，若全部失败返回空字符串。
    """
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    prompt = PROMPT_TEMPLATE.format(
        situation=str(situation),
        automatic_thought=str(auto_thought),
        cognitive_distortion=str(distortion),
        emotion=str(emotion)
    )
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.6,
        "max_tokens": 150,
        "stream": False
    }

    for attempt in range(1, max_attempts + 1):
        try:
            resp = requests.post(f"{BASE_URL}/chat/completions", json=payload, headers=headers, timeout=30)
            if resp.status_code != 200:
                print(f"尝试 {attempt}/{max_attempts}：HTTP {resp.status_code}，将重试")
                continue
            data = resp.json()
            if "choices" not in data or not data["choices"]:
                print(f"尝试 {attempt}/{max_attempts}：响应无 choices，将重试")
                continue
            raw = data["choices"][0]["message"]["content"].strip()
            alternative = clean_alternative(raw)
            # 检查内容有效性：长度至少5个字符
            if len(alternative) >= 5:
                if len(alternative) > 100:
                    print(f"提示：生成内容过长（{len(alternative)}字），仍将采用")
                return alternative
            else:
                print(f"尝试 {attempt}/{max_attempts}：生成内容过短（'{alternative}'），将重试")
        except Exception as e:
            print(f"尝试 {attempt}/{max_attempts}：请求异常 {e}，将重试")
        # 重试前稍等，避免频繁请求
        if attempt < max_attempts:
            time.sleep(1.5)
    # 所有尝试失败
    print(f"警告：经过 {max_attempts} 次尝试仍无法生成有效替代思维，返回空字符串")
    return ""

# ---------- 主流程 ----------
print("正在读取 Excel 文件...")
df = pd.read_excel(INPUT_PATH)

required_cols = ["情境/触发事件", "自动思维", "认知扭曲/标签", "情绪"]
for col in required_cols:
    if col not in df.columns:
        raise ValueError(f"Excel 文件中缺少列：{col}")

alternatives = []
total = len(df)
print(f"共 {total} 行数据，开始生成替代思维...")

for idx, row in df.iterrows():
    situation = row["情境/触发事件"]
    auto_thought = row["自动思维"]
    distortion = row["认知扭曲/标签"]
    emotion = row["情绪"]

    if pd.isna(situation) and pd.isna(auto_thought):
        alternatives.append("")
        continue

    alt = generate_alternative_with_retry(situation, auto_thought, distortion, emotion, max_attempts=3)
    alternatives.append(alt)

    print(f"进度：{idx+1}/{total} 已完成")
    time.sleep(0.6)  # 控制请求频率

df["替代思维"] = alternatives
df.to_excel(OUTPUT_PATH, index=False)
print(f"处理完成！结果已保存至 {OUTPUT_PATH}")